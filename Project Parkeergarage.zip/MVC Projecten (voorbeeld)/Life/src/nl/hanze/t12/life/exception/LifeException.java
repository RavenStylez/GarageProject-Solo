package nl.hanze.t12.life.exception;

public class LifeException extends Exception {
	private static final long serialVersionUID = -5268539085229462286L;

	public LifeException(String message) {
		super(message);
	}
}
